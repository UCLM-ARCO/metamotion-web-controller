#!/usr/bin/python3

import types
import time
import copy
from collections import namedtuple
from .sensor import Sensor
from mbientlab.metawear import MetaWear, libmetawear, parse_value
from mbientlab.metawear.cbindings import *


class Accelerometer(Sensor):
    """
    Class for represent an Accelerometer sensor that is part of a MetaMotionR device
    This class enable the user to request all the data that is provided by this accelerometer sensor
    """
    def __init__(self, board, freq, motion_samples, motion_threshold, tap_threshold):
        """
        Method for initialice the accelerometer sensor with the desired parameters. Also initializing the data,
        this method subscribe for all the accelerometer signal and active the sensor

        **Parameters:**

         * `board` *[mandatory]* this is the MetaMotionR Board where the sensor is located.
         * `freq` *[optional]* Frequency at which the acceleration is updated. By default, the frequency is
         25Hz what means that will be sent 25 acceleration signales per second.
         * `motion_samples` *[optional]* Number of samples that must overpass the `motion_threshold` in order
         to consider a motion.
         * `motion_threshold` *[optional]* Difference between the samples indicated in `motion_samples` to consider
         a motion.
         * `tap_threshold` *[optional]* Difference between samples acceleration to consider a tap.
        """
        self.acc = None
        self.step_counter = 0
        self.motion = None
        self.tap = 0
        self.logger = None
        self.acc_log = []
        self.freq = freq
        super().__init__(board)

        self.active(freq, motion_samples, motion_threshold, tap_threshold)
        self.init_measures()

    def active(self, acc_freq, motion_samples, motion_threshold, tap_threshold):
        """
        Method to configure, active and enable all the accelerometer sensors of the device

        **Parameters:**

         * `acc_freq` *[optional]* Frequency at which the acceleration is updated. By default, the frequency is
         25Hz what means that will be sent 25 acceleration signales per second.
         * `motion_samples` *[optional]* Number of samples that must overpass the `motion_threshold` in order
         to consider a motion.
         * `motion_threshold` *[optional]* Difference between the samples indicated in `motion_samples` to consider
         a motion.
         * `tap_threshold` *[optional]* Difference between samples acceleration to consider a tap.
        """
        libmetawear.mbl_mw_acc_set_odr(self.board, acc_freq)
        libmetawear.mbl_mw_acc_write_acceleration_config(self.board)
        libmetawear.mbl_mw_acc_enable_acceleration_sampling(self.board)

        libmetawear.mbl_mw_acc_bmi160_set_step_counter_mode(
            self.board, AccBmi160StepCounterMode.NORMAL)
        libmetawear.mbl_mw_acc_bmi160_reset_step_counter(self.board)
        libmetawear.mbl_mw_acc_bmi160_enable_step_counter(self.board)
        libmetawear.mbl_mw_acc_bmi160_write_step_counter_config(self.board)

        libmetawear.mbl_mw_acc_bosch_set_any_motion_count(self.board, 4)
        libmetawear.mbl_mw_acc_bosch_set_any_motion_threshold(self.board, 0.70)
        libmetawear.mbl_mw_acc_bosch_write_motion_config(self.board)
        libmetawear.mbl_mw_acc_bosch_enable_motion_detection(self.board)

        libmetawear.mbl_mw_acc_bosch_set_threshold(self.board, 1)
        libmetawear.mbl_mw_acc_bosch_set_shock_time(
            self.board, AccBoschTapShockTime._50ms)
        libmetawear.mbl_mw_acc_bosch_write_tap_config(self.board)
        libmetawear.mbl_mw_acc_bosch_enable_tap_detection(self.board, 1, 1)

        libmetawear.mbl_mw_acc_start(self.board)
        libmetawear.mbl_mw_acc_bosch_start(self.board)

    def disable(self):
        libmetawear.mbl_mw_acc_stop(self.board)
        libmetawear.mbl_mw_acc_bmi160_disable_step_counter(self.board)
        libmetawear.mbl_mw_acc_disable_acceleration_sampling(self.board)
        libmetawear.mbl_mw_acc_bosch_disable_motion_detection(self.board)
        libmetawear.mbl_mw_datasignal_unsubscribe(self.acc_signal(self.board))
        libmetawear.mbl_mw_datasignal_unsubscribe(
            libmetawear.mbl_mw_acc_bmi160_get_step_counter_data_signal(self.board))
        libmetawear.mbl_mw_datasignal_unsubscribe(
            libmetawear.mbl_mw_acc_bosch_get_motion_data_signal(self.board))
        libmetawear.mbl_mw_datasignal_unsubscribe(
            libmetawear.mbl_mw_acc_bosch_get_tap_data_signal(self.board))

    def init_measures(self):
        """
        Subscribe the signal of the accelerometers measures in order to update the data
        """
        self.on_acceleration()
        self.subscribe_step_counter()
        self.on_motion()
        self.on_tap()

    def on_acceleration(self, func=None):
        """
        Add a handler to process the data received by the signal. If there is no handler, the data is
        saved in the attribute

        **Parameter:**

         * `func` *[optional]* a handler to process the data.
        """
        if self.freq >= 100:
            self.acc_signal = libmetawear.mbl_mw_acc_get_high_freq_acceleration_data_signal
        else:
            self.acc_signal = libmetawear.mbl_mw_acc_get_acceleration_data_signal

        self.subscribe_signal('acc', self.acc_signal, func)

    def read_acceleration(self):
        """
        Return the last acceleration detected by the sensor. The acceleration is formed by the following
        fields:

        * `x`: Acceleration in **X** axis in Gs units.
        * `y`: Acceleration in **Y** axis in Gs units.
        * `z`: Acceleration in **Z** axis in Gs units.
        """
        time.sleep(0.5)
        return self.acc

    def subscribe_step_counter(self):
        self.subscribe_signal(
            'step_counter', libmetawear.mbl_mw_acc_bmi160_get_step_counter_data_signal)

    def read_step_counter(self):
        """
        Return the number of steps that the user has made
        """
        sc_signal = libmetawear.mbl_mw_acc_bmi160_get_step_counter_data_signal(
            self.board)
        libmetawear.mbl_mw_datasignal_read(sc_signal)
        time.sleep(0.5)
        return self.step_counter

    def on_motion(self, func=None):
        """
        Subscribe to motion detector data and attach a handler that receives the motion as a parameter.

        **Parameter:**

         * `func` *[optional]* a handler to process the data.
        """
        self.subscribe_signal(
            'motion', libmetawear.mbl_mw_acc_bosch_get_motion_data_signal, func)

    def read_motion(self):
        """
        Return the last motion detected by the sensor. The motion is formed by the following fields:

        * `sign`: Axis direction where the sensor is moving.
        * `x_axis_active`: 1 if the motion was produced in the **X** axis.
        * `y_axis_active`: 1 if the motion was produced in the **Y** axis.
        * `z_axis_active`: 1 if the motion was produced in the **Z** axis.
        """
        time.sleep(0.5)
        return self.motion

    def on_tap(self, func=None):
        """
        Subscribe tap data and attach a handler that receives tap as a parameter

        **Parameter:**

         * `func` *[optional]* a handler to process the data.
        """
        self.subscribe_signal(
            'tap', libmetawear.mbl_mw_acc_bosch_get_tap_data_signal, func)

    def read_tap(self):
        """
        Return the last tap detected by the sensor. The tap is formed by the following fields:

        * `sign`: Axis direction where the tap is detected.
        * `type`: **2** if only 1 tap is detected, **1** if 2 taps.
        """
        time.sleep(0.5)
        return self.tap

    def setup_logger(self):
        """
        Create and initialize an accelerometer logger
        """
        if self.freq >= 100:
            print("[WARNING] The frequency is very high, is possible that logging won't work properly for acceleration")

        acc_signal = libmetawear.mbl_mw_acc_get_acceleration_data_signal(self.board)
        super().setup_logger(acc_signal, 'logger', 'acceleration')

    def subscribe_logged_data(self):
        """
        Subscribe to the accelerometer logger in order to receive the acceleration data 
        when the download action is performed
        """
        super().subscribe_logged_data(self.acc_log, self.logger)